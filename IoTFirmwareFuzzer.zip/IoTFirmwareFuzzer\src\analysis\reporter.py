"""报告生成器 - HTML/JSON/Markdown"""
import os
import json
from datetime import datetime
from typing import Dict, List

from .crash_analyzer import CrashRecord
from ..utils import safe_mkdir, format_duration

class Reporter:
    def __init__(self, output_dir: str = "./output"):
        self.report_dir = os.path.join(output_dir, "reports")
        safe_mkdir(self.report_dir)

    def generate(self, stats: Dict, crashes: List[CrashRecord], config: Dict = None, format: str = "html") -> str:
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        fpath = os.path.join(self.report_dir, f"report_{ts}.{format}")
        if format == "html":
            content = self._gen_html(stats, crashes, config)
        elif format == "json":
            content = json.dumps({"stats": stats, "crashes": [{"id": c.id, "type": c.crash_type.value} for c in crashes], "config": config or {}}, indent=2, ensure_ascii=False)
        else:
            content = f"# IoT Fuzzer Report\n\nCrashes: {len(crashes)}\nStats: {stats}\n"
        open(fpath, "w", encoding="utf-8").write(content)
        return fpath

    def _gen_html(self, stats: Dict, crashes: List[CrashRecord], config: Dict) -> str:
        fuzzer = stats.get("fuzzer", {})
        cov = stats.get("coverage", {})
        crash_s = stats.get("crashes", {})
        rows = "".join(f'<tr><td>{c.id}</td><td>{c.crash_type.value}</td><td>{c.exploitability.value}</td><td>0x{c.pc_at_crash:08x}</td></tr>' for c in crashes)
        return f"""<!DOCTYPE html><html><head><meta charset="UTF-8"><title>IoT Fuzzer Report</title>
<style>body{{font-family:sans-serif;background:#0d1117;color:#c9d1d9;padding:20px;}}
table{{border-collapse:collapse;width:100%;}} th,td{{border:1px solid #30363d;padding:8px;}} th{{background:#21262d;}}
.stat{{display:inline-block;margin:10px;padding:15px;background:#161b22;border-radius:8px;}}
.stat .v{{font-size:2em;color:#58a6ff;}}</style></head><body>
<h1>IoT Firmware Fuzzer 测试报告</h1><p>生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
<div><span class="stat">总执行 <span class="v">{fuzzer.get('total_execs',0):,}</span></span>
<span class="stat">唯一崩溃 <span class="v">{crash_s.get('unique_crashes',0)}</span></span>
<span class="stat">覆盖率 <span class="v">{cov.get('coverage_pct','0%')}</span></span>
<span class="stat">运行时长 <span class="v">{format_duration(fuzzer.get('elapsed_secs',0))}</span></span></div>
<h2>崩溃列表</h2><table><tr><th>ID</th><th>类型</th><th>可利用性</th><th>PC</th></tr>{rows}</table>
<pre>{json.dumps(config or {}, indent=2, ensure_ascii=False)}</pre></body></html>"""
